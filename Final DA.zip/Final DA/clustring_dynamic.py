# import random

# elements = []
# for i in range(500):
#     elements.append(random.randint(1, 5000))
elements = [int(input(f"Enter Element {x+1} :")) for x in range(int(input("Enter Number of Element:")))]
k = int(input("Enter number of clusters:"))

dic_k = {}
for i in range(k):
    dic_k[f"k{i+1}"] = [elements[j] for j in range(i, len(elements), k)]

def calc_mean(dic_k):
    mean_dic = {}
    for key, val in dic_k.items():
        mean_dic[key] = sum(val) / len(val) if len(val) > 0 else 0
    return mean_dic

def closest_mean(mean_dic, ele):
    closest_key = None
    closest_val = float('inf')
    for key, val in mean_dic.items():
        dif = abs(ele - val)
        if dif < closest_val:
            closest_val = dif
            closest_key = key
    return closest_key

def k_means(dic_k):
    while True:
        mean_dic = calc_mean(dic_k)
        new_dic_k = {key: [] for key in dic_k}

        for key, val in dic_k.items():
            for ele in val:
                closest_key = closest_mean(mean_dic, ele)
                new_dic_k[closest_key].append(ele)

        if new_dic_k == dic_k:
            return dic_k

        dic_k = new_dic_k

result = k_means(dic_k)
for key,val in result.items():
    print(f"Cluster {key}: {val}")