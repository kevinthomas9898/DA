elements = [int(input(f"Enter Element {x+1} :")) for x in range(int(input("Enter Number of Element:")))]
# elements = [5,7,9,2,11,8,25,19,36,47,18,21]
k = 3
k1 = [elements[i] for i in range(0, len(elements), k)]
k2 = [elements[i] for i in range(1, len(elements), k)]
k3 = [elements[i] for i in range(2, len(elements), k)]

def calc_mean(k1, k2, k3):
    mean1 = sum(k1) / len(k1) if len(k1) > 0 else 0
    mean2 = sum(k2) / len(k2) if len(k2) > 0 else 0
    mean3 = sum(k3) / len(k3) if len(k3) > 0 else 0
    return mean1, mean2, mean3

def closest_mean(mean1, mean2, mean3, ele):
    if abs(ele - mean1) <= abs(ele - mean2) and abs(ele - mean1) <= abs(ele - mean3):
        return 1
    elif abs(ele - mean2) <= abs(ele - mean1) and abs(ele - mean2) <= abs(ele - mean3):
        return 2
    else:
        return 3

def k_means(k1, k2, k3):
    while True:
        mean1, mean2, mean3 = calc_mean(k1, k2, k3)

        new_k1, new_k2, new_k3 = [], [], []

        for i in k1 + k2 + k3:
            mean = closest_mean(mean1, mean2, mean3, i)
            if mean == 1:
                new_k1.append(i)
            elif mean == 2:
                new_k2.append(i)
            else:
                new_k3.append(i)

        if new_k1 == k1 and new_k2 == k2 and new_k3 == k3:
            break

        k1, k2, k3 = new_k1, new_k2, new_k3

    print(new_k1, new_k2, new_k3)
    return k1, k2, k3

k1, k2, k3 = k_means(k1, k2, k3)