main_list = []
unique_elements = []
element_counts = {}
 
num_sublists = int(input("How many sublists do you want to create? "))
min_support = int(input("Enter the minimum support value: "))
 
for i in range(num_sublists):
    num_elements = int(input(f"How many elements in sublist {i + 1}? "))
    sublist = []
    for j in range(num_elements):
        element = input(f"Enter element {j + 1} for sublist {i + 1}: ")
        sublist.append(element)
        if element not in unique_elements:
            unique_elements.append(element)  
            element_counts[element] = 1  
        else:
            element_counts[element] += 1  
    main_list.append(sublist)
 
supported_elements = []
for element, count in element_counts.items():
    if count > min_support:
        supported_elements.append(element)
 
print("The list of lists is:", main_list)
print("The list of unique elements is:", unique_elements)
print("The count of each element is:", element_counts)
print(f"Elements with at least {min_support} support:", supported_elements)
 
pairs_list = []
for i in range(len(supported_elements)):
    for j in range(i + 1, len(supported_elements)):
        pair = (supported_elements[i], supported_elements[j])
        pairs_list.append(pair)
 
print("The list of pairs is:", pairs_list)
 
pair_counts = {}
for pair in pairs_list:
    pair_counts[pair] = 0
 
for pair in pairs_list:
    for sublist in main_list:
        if pair[0] in sublist and pair[1] in sublist:
            pair_counts[pair] += 1
 
for pair, count in pair_counts.items():
    print(f"{pair} -> {count}")
 
 
confidences = {}
for pair in pairs_list:
    element_a_count = element_counts[pair[0]]
    confidences[pair] = pair_counts[pair] / element_a_count * 100
 
for pair, confidence in confidences.items():
    print(f"Confidence({pair[0]} -> {pair[1]}) = {confidence:.2f}%")
