data = []
n = int(input("Enter the number of data values: "))
for i in range(n):
    value = int(input("Enter value :  "))
    data.append(value)

min_value = min(data)
max_value = max(data)

# Input the new range for normalization
new_min = int(input("Enter the new minimum value: "))
new_max = int(input("Enter the new maximum value: "))

# Min-Max Normalization
normalized_data = []
for value in data:
    normalized_value = ((value - min_value) / (max_value - min_value)) * (new_max - new_min) + new_min
    normalized_data.append(normalized_value)

# Print the results
print("Original Data:", data)
print("Normalized Data:", normalized_data)
