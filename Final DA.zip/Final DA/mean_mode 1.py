
lst=[]
n=int(input("Enter number of elements :"))
i=0
while(i<n):
    j=int(input("Enter elements : "))
    lst.append(j)
    i=i+1

#calculation of mean
get_sum = sum(lst) 
mean = get_sum / n 


#calculation of mode
frequency = {}
for value in lst:
    if value in frequency:
        frequency[value] += 1
    else:
        frequency[value] = 1

# Find the maximum frequency
max_freq = max(frequency.values())

# Find the mode(s) by checking each value's frequency
modes = []
for key in frequency:
    if frequency[key] == max_freq:
        modes.append(key)

if len(modes) == 1:
    print("Mode:", modes[0])
else:
    print("Modes:", modes)
print("Mean / Average is: " + str(mean)) 



