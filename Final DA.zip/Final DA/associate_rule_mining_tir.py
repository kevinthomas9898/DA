trans = []
ip = int(input("Enter Number of Transations:"))
for i in range(ip):
    ip2 = int(input("Enter Number of items:"))
    temp = []
    for j in range(ip2):
        ip3 = input(f"Enter item {j+1}:")
        temp.append(ip3)
    trans.append(temp)

l1,l2,l3 = [],[],[]
c1,c2,c3 = [],[],[]

for i in trans:
    for j in i:
        if j not in l1:
            l1.append(j)

for i in l1:
    c=0
    for j in trans:
        for k in j:
            if i == k:
                c+=1
    c1.append(c) 

lenl1 = len(l1)

for i in range(lenl1):
    for j in range(i+1,lenl1):
        l2.append([l1[i],l1[j]])

for i in l2:
    c=0
    for j in trans:
        if i[0] in j and i[1] in j:
            c+=1
    c2.append(c)

for i in range(lenl1):
    for j in range(i+1,lenl1):
        for k in range(j+1,lenl1):
            l3.append([l1[i],l1[j],l1[k]])

for i in l3:
    c=0
    for j in trans:
        if i[0] in j and i[1] in j and i[2] in j:
            c+=1
    c3.append(c)

support = int(input("Enter Minimum Support:"))

print("\nfor l1 and c1")
for i in range(lenl1):
    if c1[i] >= support:
        print(f"{l1[i]} = {c1[i]}")
print("\nfor l2 and c2")
for i in range(len(c2)):
    if c2[i] >= support:
        print(f"{l2[i]} = {c2[i]}")
print("\nfor l3 and c3")
for i in range(len(c3)):
    if c3[i] >= support:
        print(f"{l3[i]} = {c3[i]}\n")